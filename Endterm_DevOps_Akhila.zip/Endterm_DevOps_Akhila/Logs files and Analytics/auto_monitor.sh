#!/bin/bash
echo "=== Auto Report: $(date) ===" >> report_log.txt
echo "Nginx Errors: $(grep -c '" [45]' nginx_logs)" >> report_log.txt
echo "Apache Errors: $(grep -ic 'error' apache_logs)" >> report_log.txt
echo "Total Nginx Requests: $(wc -l < nginx_logs)" >> report_log.txt
