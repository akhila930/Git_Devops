#!/bin/bash
# ============================================================
# Script: analyze_logs.sh
# Author: Akhila Macherla | 2023JULYVUGP0030
# Description: Linux-based analysis of Nginx Web Server Logs
# Course: DevOps Midterm Assignment
# ============================================================

LOG_FILE="../nginx_logs.log"
OUTPUT_DIR="../outputs"

echo "======================================================"
echo " Web Server Log Analysis - Akhila Macherla"
echo " Roll No: 2023JULYVUGP0030"
echo "======================================================"
echo ""

# ---- 1. Basic Statistics ----
echo "[1] Basic Log Statistics"
echo "------------------------"
TOTAL=$(wc -l < "$LOG_FILE")
echo "Total Log Entries: $TOTAL"
echo ""

# ---- 2. HTTP Status Code Distribution ----
echo "[2] HTTP Status Code Distribution"
echo "----------------------------------"
awk '{print $9}' "$LOG_FILE" | sort | uniq -c | sort -rn
echo ""

# ---- 3. Top 10 Most Frequent IP Addresses ----
echo "[3] Top 10 Most Frequent Client IP Addresses"
echo "---------------------------------------------"
awk '{print $1}' "$LOG_FILE" | sort | uniq -c | sort -rn | head -10
echo ""

# ---- 4. Most Requested URLs ----
echo "[4] Top 10 Most Requested URLs"
echo "-------------------------------"
awk '{print $7}' "$LOG_FILE" | sort | uniq -c | sort -rn | head -10
echo ""

# ---- 5. HTTP Method Distribution ----
echo "[5] HTTP Request Method Distribution"
echo "-------------------------------------"
awk '{print $6}' "$LOG_FILE" | tr -d '"' | sort | uniq -c | sort -rn
echo ""

# ---- 6. Filter Only 200 OK Requests ----
echo "[6] Total Successful (200 OK) Requests"
echo "----------------------------------------"
grep ' 200 ' "$LOG_FILE" | wc -l
echo ""

# ---- 7. Filter Only 404 Not Found Requests ----
echo "[7] Total 404 Not Found Requests"
echo "---------------------------------"
grep ' 404 ' "$LOG_FILE" | wc -l
echo ""

# ---- 8. Filter Only 304 Not Modified Requests ----
echo "[8] Total 304 Not Modified Requests"
echo "-------------------------------------"
grep ' 304 ' "$LOG_FILE" | wc -l
echo ""

# ---- 9. Requests Per Hour (Aggregation) ----
echo "[9] Requests Per Hour"
echo "---------------------"
awk '{print $4}' "$LOG_FILE" | cut -d: -f2 | sort | uniq -c
echo ""

# ---- 10. Bandwidth Analysis (Total Bytes Transferred) ----
echo "[10] Bandwidth Analysis"
echo "-----------------------"
awk '{sum += $10} END {printf "Total Bytes Transferred: %d bytes (%.2f KB)\n", sum, sum/1024}' "$LOG_FILE"
echo ""

# ---- 11. User Agent Frequency ----
echo "[11] Top 5 User Agents"
echo "----------------------"
awk -F'"' '{print $6}' "$LOG_FILE" | sort | uniq -c | sort -rn | head -5
echo ""

# ---- 12. Date Range in Logs ----
echo "[12] Log Date Range"
echo "-------------------"
echo -n "First Entry: "; head -1 "$LOG_FILE" | awk '{print $4}' | tr -d '['
echo -n "Last  Entry: "; tail -1 "$LOG_FILE" | awk '{print $4}' | tr -d '['
echo ""

echo "======================================================"
echo " Output files saved to: $OUTPUT_DIR/"
echo "======================================================"
