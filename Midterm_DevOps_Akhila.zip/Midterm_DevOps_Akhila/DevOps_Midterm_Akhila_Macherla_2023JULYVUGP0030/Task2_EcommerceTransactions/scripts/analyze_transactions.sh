#!/bin/bash
# ============================================================
# Script: analyze_transactions.sh
# Author: Akhila Macherla | 2023JULYVUGP0030
# Description: Linux-based analysis of E-commerce Transaction Data (tips.csv)
# Course: DevOps Midterm Assignment
# ============================================================

CSV_FILE="../tips.csv"
OUTPUT_DIR="../outputs"

echo "======================================================"
echo " E-Commerce Transaction Analysis - Akhila Macherla"
echo " Roll No: 2023JULYVUGP0030"
echo "======================================================"
echo ""

# ---- 1. Dataset Overview ----
echo "[1] Dataset Overview"
echo "--------------------"
echo "Header Row:"
head -1 "$CSV_FILE"
echo ""
TOTAL=$(tail -n +2 "$CSV_FILE" | wc -l)
echo "Total Records: $TOTAL"
echo ""

# ---- 2. Transaction Count by Day ----
echo "[2] Transaction Count by Day"
echo "-----------------------------"
tail -n +2 "$CSV_FILE" | awk -F',' '{print $5}' | sort | uniq -c | sort -rn
echo ""

# ---- 3. Transaction Count by Gender ----
echo "[3] Transactions by Customer Gender"
echo "------------------------------------"
tail -n +2 "$CSV_FILE" | awk -F',' '{print $3}' | sort | uniq -c | sort -rn
echo ""

# ---- 4. Smoker vs Non-Smoker Distribution ----
echo "[4] Smoker vs Non-Smoker Customers"
echo "------------------------------------"
tail -n +2 "$CSV_FILE" | awk -F',' '{print $4}' | sort | uniq -c | sort -rn
echo ""

# ---- 5. Meal Time Distribution ----
echo "[5] Lunch vs Dinner Distribution"
echo "---------------------------------"
tail -n +2 "$CSV_FILE" | awk -F',' '{print $6}' | sort | uniq -c | sort -rn
echo ""

# ---- 6. Average Bill and Tip ----
echo "[6] Average Bill Amount and Tip"
echo "--------------------------------"
tail -n +2 "$CSV_FILE" | awk -F',' '{bill+=$1; tip+=$2; count++} END {printf "Average Bill: $%.2f\nAverage Tip:  $%.2f\nTip Rate:     %.2f%%\n", bill/count, tip/count, (tip/bill)*100}'
echo ""

# ---- 7. Total Revenue and Tips ----
echo "[7] Total Revenue Summary"
echo "--------------------------"
tail -n +2 "$CSV_FILE" | awk -F',' '{bill+=$1; tip+=$2} END {printf "Total Bills:  $%.2f\nTotal Tips:   $%.2f\nGrand Total:  $%.2f\n", bill, tip, bill+tip}'
echo ""

# ---- 8. Highest and Lowest Bills ----
echo "[8] Highest and Lowest Transactions"
echo "-------------------------------------"
echo -n "Highest Bill: $"
tail -n +2 "$CSV_FILE" | awk -F',' '{print $1}' | sort -n | tail -1
echo -n "Lowest Bill:  $"
tail -n +2 "$CSV_FILE" | awk -F',' '{print $1}' | sort -n | head -1
echo ""

# ---- 9. Filter: High Value Transactions (bill > 20) ----
echo "[9] High-Value Transactions (bill > \$20.00)"
echo "----------------------------------------------"
tail -n +2 "$CSV_FILE" | awk -F',' '$1 > 20 {count++} END {print "Count: "count}'
echo ""

# ---- 10. Filter: Dinner Transactions Only ----
echo "[10] Dinner Transactions Summary"
echo "---------------------------------"
tail -n +2 "$CSV_FILE" | awk -F',' '$6 == "Dinner" {count++; bill+=$1; tip+=$2} END {printf "Dinner Count: %d\nAvg Dinner Bill: $%.2f\nAvg Dinner Tip:  $%.2f\n", count, bill/count, tip/count}'
echo ""

# ---- 11. Average Tip by Day ----
echo "[11] Average Tip by Day of Week"
echo "--------------------------------"
tail -n +2 "$CSV_FILE" | awk -F',' '{days[$5]+=$2; count[$5]++} END {for (d in days) printf "%-6s : $%.2f\n", d, days[d]/count[d]}' | sort
echo ""

# ---- 12. Group Size Distribution ----
echo "[12] Party Size Distribution"
echo "-----------------------------"
tail -n +2 "$CSV_FILE" | awk -F',' '{print $7}' | sort | uniq -c | sort -k2 -n
echo ""

echo "======================================================"
echo " Output files saved to: $OUTPUT_DIR/"
echo "======================================================"
